python ngcn_trainer.py --adj_pows=0,1,2,3 --retrain --l2reg=1e-3 --dataset_name=ind.citeseer --learn_rate=1 --early_stop_steps=200 --output_layer=wsum --hidden_dim=10 --replication_factor=3
